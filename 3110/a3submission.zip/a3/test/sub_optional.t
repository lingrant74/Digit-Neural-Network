$ dune exec ../bin/main.exe -- -i ../data/task4.md -o out1.txt -f plain
$ cat out1.txt
The musical *{{title}}* was composed by {{composer}} and premiered in {{year}}.

$ dune exec ../bin/main.exe -- -i ../data/task4.md -o out2.txt -f plain -s ../data/subs.csv
$ cat out2.txt
The musical Hamilton was composed by Lin-Manuel Miranda and premiered in 2015.
