$ dune exec ../bin/main.exe -- -i ../data/task4.md -o output.txt -f plain -s ../data/subs.csv
$ cat output.txt
The musical Hamilton was composed by Lin-Manuel Miranda and premiered in 2015.
