open OUnit2
open A3.Camlmark

let tests =
  "test suite"
  >::: [
         ("a trivial test" >:: fun _ -> assert_equal 0 0);
         ( "task2example" >:: fun _ ->
           let input =
             "This is **our first renderer**. It supports only a few \
              *Markdown* features."
           in
           let expected =
             "This is our first renderer. It supports only a few Markdown \
              features.\n"
           in
           let actual = Plain_text_renderer.render [] input in
           assert_equal ~printer:Fun.id expected actual );
         ( "task3example" >:: fun _ ->
           let input =
             "The musical *{{name}}* was composed by {{author}} and premiered \
              in {{year}}."
           in
           let expected =
             "The musical Hamilton was composed by Lin-Manuel Miranda and \
              premiered in 2015.\n"
           in
           let subs =
             [
               ("name", "Hamilton");
               ("author", "Lin-Manuel Miranda");
               ("year", "2015");
             ]
           in
           let actual = Plain_text_renderer.render subs input in
           assert_equal ~printer:Fun.id expected actual );
       ]

let _ = run_test_tt_main tests
