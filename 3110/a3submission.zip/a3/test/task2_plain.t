$ dune exec ../bin/main.exe -- -i ../data/task2.md -o output.txt -f plain
$ cat output.txt
This is our first renderer. It supports only a few Markdown features.
