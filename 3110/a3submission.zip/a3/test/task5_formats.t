$ dune exec ../bin/main.exe -- -i ../data/task5.md -o output.md -f markdown
$ cat output.md
# Hello

This is *Markdown* output with **bold** and `code`.

$ dune exec ../bin/main.exe -- -i ../data/task5.md -o output.html -f html
$ cat output.html
<h1>Hello</h1>
<p>This is <em>Markdown</em> output with <strong>bold</strong> and <code>code</code>.</p>
