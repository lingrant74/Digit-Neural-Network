$ dune exec ../bin/main.exe -- -i ../data/task6.md -o output.md -f markdown
$ cat output.md
## Example Code

```ocaml
let x = 42
print_int x
```

See the [OCaml website](https://ocaml.org).

$ dune exec ../bin/main.exe -- -i ../data/task6.md -o output.html -f html
$ cat output.html
<h2>Example Code</h2>
<pre><code>let x = 42
print_int x
</code></pre>
<p>See the <a href="https://ocaml.org">OCaml website</a>.</p>
