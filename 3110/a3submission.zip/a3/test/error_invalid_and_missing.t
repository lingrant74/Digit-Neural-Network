$ dune exec ../bin/main.exe -- -i ../data/task2.md -o output.txt -f nonsense
Warning: Invalid format 'nonsense'. Using 'plain'.
$ cat output.txt
This is our first renderer. It supports only a few Markdown features.

$ dune exec ../bin/main.exe -- -i ../data/does_not_exist.md -o output.txt -f plain 2>/dev/null
[1]
