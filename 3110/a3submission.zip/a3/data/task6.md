## Example Code
```
let x = 42
print_int x
```
See the [OCaml website](https://ocaml.org).