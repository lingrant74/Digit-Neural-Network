# Complete Example

This *paragraph* has **many** features and mentions `{{feature}}`.

Learn at [our site](https://example.com).

```
let x = 1
```

- First item
- Second item

End of document.

