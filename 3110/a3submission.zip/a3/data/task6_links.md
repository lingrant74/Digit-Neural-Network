Visit [OCaml](https://ocaml.org) and read about [Caml](https://caml.inria.fr).

