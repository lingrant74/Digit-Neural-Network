## Grocery List

- Milk
- Bread
- Eggs

Have fun shopping!

