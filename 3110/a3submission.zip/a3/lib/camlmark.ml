(** [substitution sub_file] loads a substitution map from a CSV file.
    Each row in the CSV should contain two columns: key and value.
    Returns a list of (key, value) pairs for text substitution.
    If the file path is empty or the file is empty, returns an empty list.
    Raises an exception if a CSV row doesn't have exactly two columns. *)
let substitution sub_file =
  if !sub_file = "" then []
  else
    Csv.load !sub_file |> Csv.square
    |> List.map (function
      | [ k; v ] -> (k, v)
      | row -> failwith "Invalid CSV row ")

(** [replace_sub subarray text] replaces placeholders in text with values from the substitution map.
    Placeholders use double curly braces syntax: {{key}}.
    All occurrences of {{key}} are replaced with the corresponding value.
    Returns the original text with all substitutions applied. *)
let replace_sub subarray text =
  List.fold_left
    (fun acc (k, y) ->
      let inside = "{{" ^ k ^ "}}" in
      BatString.nreplace ~str:acc ~sub:inside ~by:y)
    text subarray

(** Module type defining the interface for rendering backends.
    Each backend module implements how different Markdown elements
    should be formatted for a specific output format (HTML, Markdown, or plain text).
    The functor uses these functions to produce the appropriate formatted output. *)
module type BACKEND = sig
  (** Format plain text *)
  val text : string -> string
  (** Format emphasized text (italic) *)
  val emph : string -> string
  (** Format strongly emphasized text (bold) *)
  val strong : string -> string
  (** Format a paragraph *)
  val paragraph : string -> string
  (** Format a heading at the specified level (1-6) *)
  val heading : int -> string -> string
  (** Format a link with text and URL *)
  val link : string -> string -> string
  (** Render a soft line break *)
  val soft_break : unit -> string
  (** Render a hard line break *)
  val hard_break : unit -> string
  (** Format inline code *)
  val code_inline : string -> string
  (** Format a code block *)
  val code_block : string -> string
  (** Format a list of items *)
  val list : string list -> string
  (** Format a list item *)
  val list_item : string -> string
end

module Plain_text_backend : BACKEND = struct
  let text s = s
  let emph s = s
  let strong s = s
  let paragraph s = s
  let heading lvl s = s ^ "\n\n"
  let link text url = text ^ "(" ^ url ^ ")"
  let soft_break () = " "
  let hard_break () = "\n"
  let code_inline s = "`" ^ s ^ "`"

  let code_block s =
    "    " ^ String.concat "\n    " (String.split_on_char '\n' s) ^ "\n"

  let list_item s = "  <li>" ^ s ^ "</li>"

  let list items =
    "<ul>\n"
    ^ String.concat "\n" (List.map (fun s -> "  <li>" ^ s ^ "</li>") items)
    ^ "\n</ul>\n"
end

module Markdown_backend : BACKEND = struct
  let text s = s
  let emph s = "*" ^ s ^ "*"
  let strong s = "**" ^ s ^ "**"
  let paragraph s = s
  let heading lvl s = String.make lvl '#' ^ " " ^ s
  let link text url = "[" ^ text ^ "]" ^ "(" ^ url ^ ")"
  let soft_break () = " "
  let hard_break () = "  \n"
  let code_inline s = "`" ^ s ^ "`"
  let code_block s = "```\n" ^ s ^ "\n```\n"
  let list_item s = "- " ^ s
  let list items = String.concat "\n" items ^ "\n"
end

module Html_backend : BACKEND = struct
  let text s = s
  let emph s = "<em>" ^ s ^ "</em>"
  let strong s = "<strong>" ^ s ^ "</strong>"
  let paragraph s = "<p>" ^ s ^ "</p>\n"

  let heading lvl s =
    "<h" ^ string_of_int lvl ^ ">" ^ s ^ "</h" ^ string_of_int lvl ^ ">\n"

  let link text url = "<a href=\"" ^ url ^ "\">" ^ text ^ "</a>"
  let soft_break () = " "
  let hard_break () = "<br/>\n"
  let code_inline s = "<code>" ^ s ^ "</code>"
  let code_block s = "<pre><code>" ^ s ^ "</pre></code>"
  let list_item s = "- " ^ s
  let list items = String.concat "\n" items ^ "\n\n"
end

(** Functor that creates a renderer from a backend module.
    Takes a backend module and produces a complete Markdown renderer.
    The renderer processes the OMD abstract syntax tree and delegates
    formatting to the backend module's functions. *)
module MakeRenderer (B : BACKEND) = struct
  open Omd

  (** Recursively render inline Markdown elements (text, emphasis, links, etc.) *)
  let rec render_inline subs element =
    match element with
    | Omd.Text (_, s) -> B.text (replace_sub subs s)
    | Omd.Emph (_, inside) -> B.emph (render_inline subs inside)
    | Omd.Strong (_, inside) -> B.strong (render_inline subs inside)
    | Omd.Link (_, { label; destination = url; title }) ->
        B.link (render_inline subs label) url
    | Omd.Soft_break _ -> B.soft_break ()
    | Omd.Hard_break _ -> B.hard_break ()
    | Omd.Concat (_, inside) ->
        String.concat "" (List.map (render_inline subs) inside)
    | Omd.Code (_, s) -> B.code_inline s
    | _ -> ""

  (** Render block-level Markdown elements (paragraphs, headings, code blocks, lists) *)
  let render_block subs element =
    match element with
    | Omd.Paragraph (_, inside) -> B.paragraph (render_inline subs inside)
    | Omd.Heading (_, lvl, inside) -> B.heading lvl (render_inline subs inside)
    | Omd.Code_block (_, _, s) -> B.code_block s
    | Omd.List (_, _, _, items) ->
        let rendered_items =
          List.filter_map
            (function
              | [ Omd.Paragraph (_, inlines) ] ->
                  Some (B.list_item (render_inline subs inlines))
              | _ -> None)
            items
        in
        B.list rendered_items
    | _ -> ""

  (** Render a complete document with proper spacing *)
  let render_doc subs element =
    let body = String.concat "\n\n" (List.map (render_block subs) element) in
    if body <> "" && body.[String.length body - 1] <> '\n' then body ^ "\n"
    else body

  (** Main render function: takes substitutions, Markdown string, and produces formatted output *)
  let render subs element =
    let text = Omd.of_string element in
    render_doc subs text
end

(** Renderer that outputs plain text (strips all formatting) *)
module Plain_text_renderer = MakeRenderer (Plain_text_backend)

(** Renderer that outputs Markdown (preserves formatting) *)
module Markdown_renderer = MakeRenderer (Markdown_backend)

(** Renderer that outputs HTML tags *)
module Html_renderer = MakeRenderer (Html_backend)

(** Default renderer (plain text) *)
module Default_renderer = Plain_text_renderer

(** [render_with_format format subs input] renders Markdown with the specified format.
    @param format One of "plain", "markdown", or "html"
    @param subs List of (key, value) pairs for text substitution
    @param input The Markdown string to render
    @return The rendered output string *)
let render_with_format format subs input =
  match format with
  | "plain" -> Plain_text_renderer.render subs input
  | "markdown" -> Markdown_renderer.render subs input
  | "html" -> Html_renderer.render subs input
  | _ -> Plain_text_renderer.render subs input
