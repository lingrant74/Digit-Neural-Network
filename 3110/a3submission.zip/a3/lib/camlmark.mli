val render_with_format : string -> (string * string) list -> string -> string
(** [render_with_format format subs input] renders Markdown with the specified
    format.
    @param format One of "plain", "markdown", or "html"
    @param subs List of (key, value) pairs for text substitution
    @param input The Markdown string to render
    @return The rendered output string *)

val substitution : string ref -> (string * string) list
(** [substitution sub_file] loads a substitution map from a CSV file. Returns a
    list of (key, value) pairs for text substitution. If the file is empty,
    returns an empty list. *)

val replace_sub : (string * string) list -> string -> string
(** [replace_sub subs text] replaces placeholders in text with values from the substitution map.
    Placeholders are in the form {{key}} and are replaced with the corresponding value.
    @param subs List of (key, value) pairs for substitution
    @param text The text containing placeholders
    @return The text with placeholders replaced *)

(** {4 Testing Modules}
    These modules are exposed for testing purposes. *)

(** Renderer that outputs plain text (strips all formatting) *)
module Plain_text_renderer : sig
  val render : (string * string) list -> string -> string
  (** [render subs input] renders Markdown as plain text *)
end

(** Renderer that outputs Markdown (preserves formatting) *)
module Markdown_renderer : sig
  val render : (string * string) list -> string -> string
  (** [render subs input] renders Markdown as Markdown *)
end

(** Renderer that outputs HTML tags *)
module Html_renderer : sig
  val render : (string * string) list -> string -> string
  (** [render subs input] renders Markdown as HTML *)
end

(** Default renderer (plain text) *)
module Default_renderer : sig
  val render : (string * string) list -> string -> string
  (** [render subs input] renders using the default renderer *)
end
